const jwt = require('jsonwebtoken')

function verifyUser(req,res,next){
  console.log(req.headers["auth-token"] )
  try{
    const decoded = jwt.verify(req.headers["auth-token"] , process.env.JWT_KEY)
    req.userData = decoded;
    next();
  }
  catch(e){
    res.json({
      message:"failure",
      type:"FORBIDDEN"
    })
  }
}

module.exports = verifyUser